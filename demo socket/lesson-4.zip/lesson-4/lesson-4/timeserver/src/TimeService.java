
public interface TimeService extends java.rmi.Remote {
    java.util.Date getTime() throws java.rmi.RemoteException;
}

